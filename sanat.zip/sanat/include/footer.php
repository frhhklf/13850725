</section>
			</section>
		</section>
		
		<footer class="divtable">
			<section class="divtablerow">
				<article class="divtablecell"> مالکیت مادی و معنوی سایت </article>
			</section>
		</footer>
		
		
		</div>
	</div>
</div>




</body>


</html>