<?php
include("include/header.php");


//$link=mysqli_connect("localhost","root","","shop_db");

//if(mysqli_connect_errno())
	//exit("شرح خطا بدین گونه است:" .mysqli_connect_error());

//$query="SELECT * FROM product";
//$result= mysqli_query($link,$query);

?>
<table style=" width:100%;" border="1px">
<tr>
<?php


//$counter=0;
//while($row=mysqli_fetch_array($result))
// $counter++;
?>

<td style="border-style:dotted dashed; vertical-align:top; width:100%; "  align="center" >
<b>
چارت سازمانی
</b>
</td>
</tr>
<tr>
	<td>
		<img src="img/chart.jpg" width="70%" height="80%"/>
	</td>

</tr>

</table>

<?php
 include("include/footer.php");
 ?>